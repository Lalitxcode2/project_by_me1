var mouseEvent = "empty";
var last_x,last_y;

canvas = document.getElementById("canvas");
ctx = canvas.getContext("2d");

color = "blue";

ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(200,200,70,0, 2*Math.PI);
ctx.stroke();

canvas.addEventListener("mousedown",mouse_down);

function mouse_down(t)
{
    mouse_x = t.clientX - canvas.offsetLeft;
    mouse_y = t.clientY - canvas.offsetTop; 

    console.log("X = " + mouse_x +", Y = " + mouse_y);
    circle(mouse_x,mouse_y);


}

function circle(mouse_x,mouse_y)
{
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.arc(mouse_x,mouse_y,70,0, 2*Math.PI);
    ctx.stroke();
      
}
function nextpage(){
    window.location = "index2.html";
}
