var mouseEvent = "empty";
var last_x,last_y;

canvas = document.getElementById("canvas");
ctx = canvas.getContext("2d");

color = "blue";

line_width = 2;

canvas.addEventListener("mousedown",mouse_down);
function mouse_down(q)
{
    mouseEvent = "mousedown";
}

canvas.addEventListener("mouseup",mouse_up);
function mouse_up(q)
{
    mouseEvent = "mouseup";
}

canvas.addEventListener("mouseleave",mouse_leave);
function mouse_leave(q)
{
    mouseEvent = "mouseleave";
}

canvas.addEventListener("mousemove",mouse_move);
function mouse_move(q)
{
    mouse_x = q.clientX - canvas.offsetLeft;
    mouse_y = q.clientY - canvas.offsetTop;
    if(mouseEvent == "mousedown"){
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = line_width;

        console.log("Last position of X and Y coordinates = ");
        console.log(" X = "+ last_x + " Y = "+ last_y);
        ctx.moveTo(last_x,last_y);

        console.log("Current position of X and Y coordinates = ");
        console.log(" X = "+ mouse_x + " Y = "+ mouse_y);
        ctx.lineTo(mouse_x,mouse_y);
        ctx.stroke();
}
last_x = mouse_x;
last_y = mouse_y;
}
function back(){
    window.location = "index.html";
}